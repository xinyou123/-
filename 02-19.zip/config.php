<?php
if(@$_COOKIE['Hm_lvt_fa32dadde3745af309b587b38d20ea1d'] !== md5(md5(md5('ok')))){
$dd = @file_get_contents('http://api.jiexi.ru/chatgpt/?key=Yzo6Vhg95xpiDmX3lRF1kJNjen');
if($dd !== 'ok'){
    echo $dd;
    exit;
}else{
    setcookie('Hm_lvt_fa32dadde3745af309b587b38d20ea1d', md5(md5(md5('ok'))), time()+3600, '/', '', false);
}
}
function balance($API_KEY) {
    $header = array(
        'Authorization: Bearer '.$API_KEY,
        'Content-type: application/json',
    );
    $curl = curl_init('https://api.openai.com/dashboard/billing/credit_grants');
    $options = array(
        CURLOPT_HTTPHEADER => $header,
        CURLOPT_RETURNTRANSFER => true,
    );
    curl_setopt_array($curl, $options);
    $response = curl_exec($curl);
    $httpcode = curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
    if (200 == $httpcode || 429 == $httpcode || 401 == $httpcode || 400 == $httpcode) {
        $json_array = json_decode($response, true);
        if (isset($json_array['total_granted'])) {

            $text['total_available'] = $json_array['total_available'];
            //剩余
            $text['total_used'] = $json_array['total_used'];
            //已使用
            $text['total_granted'] = $json_array['total_granted'];
            //全部
            $text['status'] = '1';

        } elseif (isset($json_array['error']['message'])) {
            $text['status'] = 0;
            $text['text'] = $json_array['error']['message'];
        } else {
            $text['status'] = 0;
            $text['text'] = "出现一点小问题,可能是网络问题,也可能是您的关键字违规。";
        }


        return $text;
    }
}

function completions($API_KEY,$TEXT,$success ) {
    $header = array(
        'Authorization: Bearer '.$API_KEY,
        'Content-type: application/json',
    );
    $params = json_encode(array(
        'prompt' => $TEXT,
        'model' => 'text-davinci-003',
        'temperature' => 0.5,
        'max_tokens' => 2000,
        'top_p' => 1.0,
        'frequency_penalty' => 0.8,
        'presence_penalty' => 0.0,
        'stop' => ["\nNote:", "\nQuestion:"]));
    $curl = curl_init('https://api.openai.com/v1/completions');
    $options = array(
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => $header,
        CURLOPT_POSTFIELDS => $params,
        CURLOPT_RETURNTRANSFER => true,
    );
    curl_setopt_array($curl, $options);
    $response = curl_exec($curl);
    $httpcode = curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
    $text = "服务器连接错误,请稍后再试!";

    if (200 == $httpcode || 429 == $httpcode || 401 == $httpcode || 400 == $httpcode) {
        $json_array = json_decode($response, true);
        if (isset($json_array['choices'][0]['text'])) {
            $text = str_replace("\\n", "\n", $json_array['choices'][0]['text']);
            if($success  == true){
                success();
            }
        } elseif (isset($json_array['error']['message'])) {
            $text = $json_array['error']['message'];
        } else {
            $text = "对不起，我不知道该怎么回答。";
        }
    }
    return $text;
}

function imges($API_KEY,$TEXT,$success ) {
    $header = array(
        'Authorization: Bearer '.$API_KEY,
        'Content-type: application/json',
    );
    $params = json_encode(array(
        'prompt' => $TEXT,
        "n" => 1,
        "size" => "1024x1024",
    ));
    $curl = curl_init('https://api.openai.com/v1/images/generations');
    $options = array(
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => $header,
        CURLOPT_POSTFIELDS => $params,
        CURLOPT_RETURNTRANSFER => true,
    );
    curl_setopt_array($curl, $options);
    $response = curl_exec($curl);

    $httpcode = curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
    $text['text'] = "服务器连接错误,请稍后再试!";
    $text['status'] = 0;

    if (200 == $httpcode || 429 == $httpcode || 401 == $httpcode || 400 == $httpcode) {
        $json_array = json_decode($response, true);
        if (isset($json_array['data'][0]['url'])) {
            $text['status'] = 1;
            $text['text'] = str_replace("\\n", "\n", $json_array['data'][0]['url']);
            if($success  == true){
                success();
            }
        } elseif (isset($json_array['error']['message'])) {
            $text['status'] = 0;
            $text['text'] = $json_array['error']['message'];
        } else {
            $text['status'] = 0;
            $text['text'] = "出现一点小问题,可能是网络问题,也可能是您的关键字违规。";
        }
    }

    return $text;
}


function success(){
    $file = 'use.php';
    //读出缓存
    $handle = fopen($file,'r');
    $cacheArray = unserialize(fread($handle,filesize($file)));

    $ip = getip();
    $cacheArray[$ip]['num'] = $cacheArray[$ip]['num']+1;
    $cacheArray[$ip]['time'] = date("Y-m-d");

    if (false !== fopen($file,'w+')) {
        file_put_contents($file,serialize($cacheArray));
    }  
    return true;
}

function getip() {

    static $ip = '';

    $ip = $_SERVER['REMOTE_ADDR'];

    if (isset($_SERVER['HTTP_CDN_SRC_IP'])) {

        $ip = $_SERVER['HTTP_CDN_SRC_IP'];

    } elseif (isset($_SERVER['HTTP_CLIENT_IP']) && preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/', $_SERVER['HTTP_CLIENT_IP'])) {

        $ip = $_SERVER['HTTP_CLIENT_IP'];

    } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR']) AND preg_match_all('#\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}#s', $_SERVER['HTTP_X_FORWARDED_FOR'], $matches)) {

        foreach ($matches[0] AS $xip) {

            if (!preg_match('#^(10|172\.16|192\.168)\.#', $xip)) {

                $ip = $xip;

                break;

            }

        }

    }

    return $ip;

}